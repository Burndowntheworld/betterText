from .src.bettertext import (
    foreground,
    background,
    reverse,
    flip,
    vertical,
    typewrite,
    number,
    repeat,
    hashtag,
    abreviate,
    blink
)